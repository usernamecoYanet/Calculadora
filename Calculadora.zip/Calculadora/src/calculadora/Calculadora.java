/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadora;

import javax.swing.*;
public class Calculadora{

    /**
     * @param args the command line arguments
     */
    public static void calculadora(String[] args) {
        int opcion = 0 ;
        double numero1,numero2,s,r,m,d,p,raiz ; 
        do{
            opcion = Integer.parseInt(JOptionPane.showInputDialog("calculadora \n " +
                    "1: suma \n"+
                    "2: resta \n"+
                    "3:multiplicacion \n"+
                    "4:division \n"+
                    "5:potencia\n"+
                    "6:raiz \n"+
                    "7:salir \n"+
                    "\n INgresa una opcion:"));
            switch (opcion)
            {
                case 1:
                    numero1=Double.parseDouble(JOptionPane.showInputDialog("Ingresa el primer numero:"));
                    numero2=Double.parseDouble(JOptionPane.showInputDialog("Ingresa el segundo numero:"));
                    s=numero1+numero2;
                    JOptionPane.showInputDialog(null,"la suma es"+s);
                break;
                case 2:
                    numero1=Double.parseDouble(JOptionPane.showInputDialog("Ingresa el primer numero:"));
                    numero2=Double.parseDouble(JOptionPane.showInputDialog("Ingresa el segundo numero:"));
                     r=numero1-numero2;
                    JOptionPane.showInputDialog(null,"la resta es"+r);
                break;
                case 3:
                    numero1=Double.parseDouble(JOptionPane.showInputDialog("Ingresa el primer numero:"));
                    numero2=Double.parseDouble(JOptionPane.showInputDialog("Ingresa el segundo numero:"));
                    m=numero1*numero2;
                    JOptionPane.showInputDialog(null,"la multiplicacion es"+m);
                break;
                case 4:
                    numero1=Double.parseDouble(JOptionPane.showInputDialog("Ingresa el primer numero:"));
                    numero2=Double.parseDouble(JOptionPane.showInputDialog("Ingresa el segundo numero:"));
                    d=numero1/numero2;
                    JOptionPane.showInputDialog(null,"la division  es"+d);
                break;
                case 5:
                    numero1=Double.parseDouble(JOptionPane.showInputDialog("Ingresa el primer numero:"));
                    numero2=Double.parseDouble(JOptionPane.showInputDialog("Ingresa el segundo numero:"));
                    p=Math.pow(numero1, numero2);
                    JOptionPane.showInputDialog(null,numero1+ " elevado a la " + numero2 + " es igual a " + p);
                break;
                case 6:
                    numero1=Double.parseDouble(JOptionPane.showInputDialog("Ingresa el primer numero:"));
                     raiz =Math.sqrt(numero1);
                     JOptionPane.showInputDialog(null,"La raiz cuadrada de "+ numero1 +  " es: " + raiz);
                break;                
            }}
 while (opcion!=7);
  }   


