package CalculadoraHerencia;

public class CalculadoraHerencia {

    public static void main(String[] args) {
        
     double n1 = 10;
     double n2 = 5;
                
        //suma
        Suma sum = new Suma(n1,n2);
        sum.mostrarResultado();
        
        //resta
        Resta res = new Resta(n1,n2);
        res.mostrarResultado();
        
        //multiplicacion
        Multiplicacion mul = new Multiplicacion(n1,n2);
        mul.mostrarResultado();
        
        //division
        Divicion div = new Divicion(n1,n2);
        div.mostrarResultado();
    }
    
}
